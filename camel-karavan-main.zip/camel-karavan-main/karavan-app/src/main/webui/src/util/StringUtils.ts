export function isEmpty(str: string) {
    return !str?.trim();
}
